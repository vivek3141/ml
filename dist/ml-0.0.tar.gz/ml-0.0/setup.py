from setuptools import setup

setup(
    name='ml',
    version='0.0',
    packages=['nn','k_means','linear_regression','nn','logistic_regression',],
    author="Vivek Verma",
    author_email="vivekverma3141@gmail.com",
    url="https://github.com/vivek3141/ml",
    license='MIT',
    long_description=open('README.txt').read(),
)